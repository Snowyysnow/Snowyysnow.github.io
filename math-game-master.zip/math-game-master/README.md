# math-game

This is a basic game that tests your mental math skills.

Right now it just handles addition and numbers between 1 and 20,
but it could be expanded to give the user a choice of modes (easy,
  medium, hard, etc...) and include more types of math operations.
